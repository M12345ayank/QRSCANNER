from django.contrib import admin
from scanner.models import Register,Login

# Register your models here.
admin.site.register(Register)
admin.site.register(Login)
